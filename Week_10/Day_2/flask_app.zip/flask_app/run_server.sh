export FLASH_APP=application.py
export FLASK_DEBUG=1
flask run
